############################################################
#
#	Calling Functions
#
############################################################


$x = 10; 
AddOne();
AddOne();
AddOne();
AddOne();
AddOne();
AddOne();
AddOne();
AddOne();
1;

sub AddOne
{
    $x++;
    print "$x \n";
}

