############################################################
#
#        Exercise 2
#
#		 Double size of array be repeating its data
#
############################################################

my @data = (5, 8, 10, 6, 3, 4, 7, 2);

@result = Modify(@data);
print "@data \n";
print "@result \n";

sub Modify {
    return (@_, @_);
}
