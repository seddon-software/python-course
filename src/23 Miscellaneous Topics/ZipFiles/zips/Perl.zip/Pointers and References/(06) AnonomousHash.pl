##################################################
#
#     hash references
#
##################################################

# set up reference to an anonomous hash
$hashRef = { 'Tom'  => 539, 
	         'Ali'  => 377, 
	         'Mary' => 470 };

# we can access the hash using two different notations
# use $$ notation
print "$$hashRef{'Tom'} \n";
print "$$hashRef{'Ali'} \n";
print "$$hashRef{'Mary'} \n";

print "---- \n";

# use -> notation
print "$hashRef->{'Tom'} \n";
print "$hashRef->{'Ali'} \n";
print "$hashRef->{'Mary'} \n";


1