use strict;

my ($number, $x);

$x = 21;

$number = $x <  5 ? 100
        : $x < 10 ? 200
        : $x < 15 ? 300
        : $x < 20 ? 400
        : $x < 25 ? 500
        :           600
        ;

1