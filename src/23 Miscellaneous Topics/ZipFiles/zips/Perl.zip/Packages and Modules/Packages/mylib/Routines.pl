##########################################################
#
#	Functions
#
##########################################################

package Func;

sub Sub1
{
  print "This is function 1 \n";
}

sub Sub2
{
  print "This is function 2 \n";
}

sub Sub3
{
  print "This is function 3 \n";
}

############################################################

package Sub;

sub Sub1
{
  print "This is subroutine 1 \n";
}

sub Sub2
{
  print "This is subroutine 2 \n";
}

sub Sub3
{
  print "This is subroutine 3 \n";
}


return 1;








