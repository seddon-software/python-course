do "f1.pl";
do "f2.pl";
do "f3.pl";

print "main \n";

f11();
f12();
f13();
f21();
f22();
f23();
f31();
f32();
f33();

1
