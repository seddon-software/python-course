##########################################################
#
#	ModuleA
#
##########################################################

package ModuleA;

use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(f1 f2 f3);

sub f1 { print "This is f1 in ModuleA\n"; }
sub f2 { print "This is f2 in ModuleA\n"; }
sub f3 { print "This is f3 in ModuleA\n"; }


return 1;
