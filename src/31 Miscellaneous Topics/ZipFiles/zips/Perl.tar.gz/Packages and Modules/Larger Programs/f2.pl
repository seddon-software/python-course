sub f21
{
	print "f21 \n";	
}

sub f22
{
	print "f22 \n";
}

sub f23
{
	print "f23 \n";
}
