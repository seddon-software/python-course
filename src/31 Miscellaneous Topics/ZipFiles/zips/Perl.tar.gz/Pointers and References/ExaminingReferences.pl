$refHash   = \ my %myHash;
$refArray  = \ my @myArray;
$refScalar = \ my $myScalar;

print ref($refHash), "\n";
print ref($refArray), "\n";
print ref($refScalar), "\n";


1