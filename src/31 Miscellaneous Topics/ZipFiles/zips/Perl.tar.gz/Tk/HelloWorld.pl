############################################################
#
#	Hello World Example
#
############################################################

  use Tk;

  my $mw = new MainWindow;
  $mw->title("Hello World");
  $mw->minsize(300, 300);

  $mw->Button(-text => "Done",
              -command => sub { exit })->pack;
  MainLoop;

