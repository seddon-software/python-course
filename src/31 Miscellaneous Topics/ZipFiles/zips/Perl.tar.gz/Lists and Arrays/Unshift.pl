##########################################################
#
#	Unshift
#
##########################################################

@array = (1 .. 10);
print "@array \n";

unshift @array, (11);
print "@array \n";

unshift @array, (12);
print "@array \n";

unshift @array, (13);
print "@array \n";

unshift @array, (14);
print "@array \n";
