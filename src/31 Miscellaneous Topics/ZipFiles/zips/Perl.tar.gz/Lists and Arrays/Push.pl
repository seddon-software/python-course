##########################################################
#
#	Push
#
##########################################################

@array = (1 .. 7);
print "@array \n";

push(@array, 8);
print "@array \n";

push(@array, 9);
print "@array \n";

push(@array, 10);
print "@array \n";

1;
