void say_hello(const char* name);
void say_goodbye(const char* name);
