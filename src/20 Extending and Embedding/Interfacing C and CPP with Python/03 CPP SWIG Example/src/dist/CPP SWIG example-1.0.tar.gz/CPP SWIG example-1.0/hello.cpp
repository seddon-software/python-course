#include <iostream>
#include "hello.h"
using namespace std;


void say_hello(const char* name) {
    cout << "Hello " << name << endl;
}

void say_goodbye(const char* name) {
    cout << "Goodbye " << name << endl;
}
