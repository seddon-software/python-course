#include <stdio.h>

double sumOfRoots(int n);
