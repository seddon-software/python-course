def f2():
    print("f2")
    