def f1():
    print ("f1")
    