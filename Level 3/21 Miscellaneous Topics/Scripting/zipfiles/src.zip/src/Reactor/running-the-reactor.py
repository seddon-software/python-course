from twisted.internet import reactor

print "Running the reactor..."
reactor.run( )
print "Reactor stopped."