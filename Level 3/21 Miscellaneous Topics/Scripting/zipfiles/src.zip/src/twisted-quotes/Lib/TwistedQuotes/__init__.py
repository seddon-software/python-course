"""
Twisted Quotes
"""
