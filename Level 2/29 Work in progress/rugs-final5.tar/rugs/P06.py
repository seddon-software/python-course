#! /home/chris/anaconda3/bin/python

import re
import time
import pyttsx3
from pyttsx3.voice import Voice

# done lines: 1 - 69
# next line: 70

codes = {
    'd' : "dark",
    'o' : "orange",
    'p' : "pink",
    'l' : "lime",
    'b' : "beige",
    'w' : "white",
    'g' : "green",
    'y' : "yellow",
    't' : "teal",
    'm' : "mid",
    ' ' : "-"
}

FILENAME = "data/RugPattern"
inFile = open(FILENAME, "r")
lines = inFile.readlines()
lines = "".join(lines)

ROWS = 320

start = int(input("Enter starting line number: "))

for lineNumber in range(start, ROWS+1):
    print(f"Line Number: {lineNumber}")
    pattern = "{lineNumber:0>3}.*\\n.*\\n.*\\n".format(lineNumber=lineNumber)
    pattern = re.compile(pattern)

    match = pattern.search(lines, re.MULTILINE)
    line = match.group()
    line = line[4:]
    line = re.sub("[\n]", "", line)
    line = re.sub("[ ]+", " ", line)

    BATCH = 3
    print(len(line))
    for batch in range(0, len, BATCH):
        input("\n<")
        print(f"{line[batch:batch+BATCH]}", flush=True)
        print(f"{lineNumber}: {line[:batch+BATCH]}", flush=True)

        engine = pyttsx3.init()
        engine.setProperty('rate', 150)

        for c in line[batch:batch+BATCH]:
            color = codes[c]
            engine.say(color)
        engine.runAndWait()


