import time
import pyttsx3
engine = pyttsx3.init()
#engine.say("I will speak this text")
line = "bdmmw wwwmm wwwww wwbbb bbbbb bbbbm wwmbm wwwwm mwwww wmwww wwwdd dddww dwwmm wwdgb omppp ddpdd dlldp omood mbmbb dmm"
#for c in line:
#voices = engine.getProperty('voices')
engine.setProperty('rate', 30)
#for voice in voices:
#    print(voice.id)
#    engine.setProperty('voice', voice.id)

# engine.setProperty('rate', 100)

words = ["beige", "dark brown", "mid brown", "mid brown", "white"]
for word in words:
    engine.say(word)
    input("<")
engine.runAndWait()
