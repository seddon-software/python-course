'''
This program calls all the other programs
'''

import part1
import part2
import part3
