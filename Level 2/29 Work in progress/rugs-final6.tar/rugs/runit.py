#! /home/chris/anaconda3/bin/python
'''
This program calls all the other programs
'''

import P01_CreateNormalisedFiles
import P02_CreateNumpyArrayFiles_and_PIL_Image
import P03_GenerateSpreadSheet
import P04_PerformCorrections_and_DuplicateQuadrants
import P05_GeneratePattern
