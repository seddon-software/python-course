#! /home/chris/anaconda3/bin/python
'''
This program calls all the other programs
'''

import part1
import part2
import part3
# import duplicate
