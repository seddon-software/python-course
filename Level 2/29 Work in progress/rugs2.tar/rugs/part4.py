import numpy as np
import matplotlib.pyplot as plt
import openpyxl, re
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from openpyxl.cell.cell import Cell
from PIL import ImageColor

def getActiveWorkbookAndSheet(filename):
    wb = load_workbook(filename=f'data/{filename}.xlsx')
    return wb, wb.active

def getCellColor(cell):
    parameters = cell.fill.__repr__()
    parameterList = parameters.split("\n")
    pattern = re.compile(r"^rgb='(.+?)'.*$")
    matcher = pattern.search(parameterList[4])
    result = matcher.group(1)
    return result[2:]       # remove transparency

codes = {
    (101,  67,  33):'d',
    (255, 165,   0):'o',
    (255, 182, 193):'p',
    (152, 251, 152):'l',
    (245, 245, 220):'b',
    (255, 255, 255):'w',
    ( 34, 139,  34):'g',
    (255, 255,   0):'y',
    (  0,   0, 255):'t',
    (165,  42,  42):'m',
    (  0,   0,   0):'x'
}

wb, ws = getActiveWorkbookAndSheet("MASTER")

rows = (0, 10)
cols = (140, 150)

for row in range(1, 10):
    for col in range(140, 199):
        color = f"#{getCellColor(ws.cell(row, col))}"
        rgb = ImageColor.getcolor(color, "RGB")
        try:
            code = codes[rgb]
        except:
            print(row, col, "unknown color")
        print(code, end="")
        if col%5 == 0: print(" ", end="")
        if col%50 == 0: print(" ")
#        print(row, col, code, end="")
    print()
    print()

