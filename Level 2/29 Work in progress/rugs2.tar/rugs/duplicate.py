import numpy as np
import matplotlib.pyplot as plt
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from openpyxl.cell.cell import Cell
import openpyxl, re

def getActiveWorkbookAndSheet(filename):
    wb = load_workbook(filename=f'data/{filename}.xlsx')
    return wb, wb.active

def getCellColor(cell):
    parameters = cell.fill.__repr__()
    parameterList = parameters.split("\n")
    pattern = re.compile(r"^rgb='(.+?)'.*$")
    matcher = pattern.search(parameterList[4])
    result = matcher.group(1)
    return result

def duplicate(d):
    sourceRowStart = ws[d['start']].row
    sourceColStart = ws[d['start']].column
    sourceRowEnd = ws[d['end']].row
    sourceColEnd = ws[d['end']].column
    targetRowStart = ws[d['target']].row
    targetColStart = ws[d['target']].column
    
    rowOffset = targetRowStart - sourceRowStart
    colOffset = targetColStart - sourceColStart

    for row in range(sourceRowStart, sourceRowEnd+1):
        for col in range(sourceColStart, sourceColEnd+1):
            color = getCellColor(ws.cell(row, col))
            fill = PatternFill(start_color=f"{color}", fill_type = "solid")
            ws.cell(row+rowOffset, col+colOffset).fill = fill

def diff(first, second):
    '''
    first is cell name:   "XX88"
    second is cell name:  "YY99"
    '''
    return (ws[first].row    - ws[second].row, 
            ws[first].column - ws[second].column)

def newCell(base, offset):
    '''
    base is cell name:  "XX99"
    offset is a tuple:  (rows, cols)
    '''
    row, column = offset
    newRow = ws[base].row + row
    newColumn = ws[base].column + column
    cell = ws.cell(newRow, newColumn)
    return cell.coordinate

wb, ws = getActiveWorkbookAndSheet("MASTER")
duplicate({'start':"FL47", 'end':"GP86", 'target':"FL87"})
duplicate({'start':"FL47", 'end':"GP86", 'target':"FL126"})
duplicate({'start':"FL47", 'end':"GP86", 'target':"FL165"})
duplicate({'start':"FL47", 'end':"GP86", 'target':"FL204"})
duplicate({'start':"FL47", 'end':"GP86", 'target':"FL243"})
target = newCell("EA1", diff("EA1", "FO1"))
duplicate({'start':"EA1",  'end':"FO32", 'target':target})
target = newCell(target, diff("EA1", "FO1"))
duplicate({'start':"EA1",  'end':"FO32", 'target':target})
target = newCell(target, diff("EA1", "FO1"))
duplicate({'start':"EA1",  'end':"FO32", 'target':target})
FILENAME="MASTER"
wb.save(f'data/{FILENAME}.xlsx')
print("done")
