import numpy as np
import matplotlib.pyplot as plt
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from openpyxl.cell.cell import Cell
import openpyxl, re
from PIL import ImageColor

codes = {
    'd':(101,  67,  33),
    'o':(255, 165,   0),
    'p':(255, 182, 193),
    'l':(152, 251, 152),
    'b':(185, 185, 185),
    'w':(255, 255, 255),
    'g':( 34, 139,  34),
    'y':(255, 255,   0),
    't':(  0,   0, 255),
    'm':(165,  42,  42),
}

def getActiveWorkbookAndSheet(filename):
    wb = load_workbook(filename=f'data/{filename}.xlsx')
    return wb, wb.active

def getCellColor(cell):
    parameters = cell.fill.__repr__()
    parameterList = parameters.split("\n")
    pattern = re.compile(r"^rgb='(.+?)'.*$")
    matcher = pattern.search(parameterList[4])
    result = matcher.group(1)
    return result

def duplicate(d):
    sourceRowStart = ws[d['start']].row
    sourceColStart = ws[d['start']].column
    sourceRowEnd = ws[d['end']].row
    sourceColEnd = ws[d['end']].column
    targetRowStart = ws[d['target']].row
    targetColStart = ws[d['target']].column
    
    rowOffset = targetRowStart - sourceRowStart
    colOffset = targetColStart - sourceColStart

    for row in range(sourceRowStart, sourceRowEnd+1):
        for col in range(sourceColStart, sourceColEnd+1):
            color = getCellColor(ws.cell(row, col))
            fill = PatternFill(start_color=f"{color}", fill_type = "solid")
            ws.cell(row+rowOffset, col+colOffset).fill = fill

def diff(first, second):
    '''
    first is cell name:   "XX88"
    second is cell name:  "YY99"
    '''
    return (ws[first].row    - ws[second].row, 
            ws[first].column - ws[second].column)

def newCell(base, offset):
    '''
    base is cell name:  "XX99"
    offset is a tuple:  (rows, cols)
    '''
    row, column = offset
    newRow = ws[base].row + row
    newColumn = ws[base].column + column
    cell = ws.cell(newRow, newColumn)
    return cell.coordinate

ROWS = 160*2
COLS = 99*2

# quad1   ROWS   1...160    COLS   1... 99
# quad2   ROWS 160...  1    COLS 198...100
# quad3   ROWS 161...320    COLS   1... 99
# quad4   ROWS 161...320    COLS 198...100
#                 321               199
def duplicateQuadrants():
    # quadrant 1
    for row1 in range(1, 161):
        row2 = row1
        for col1 in range(1, 100):
            col2 = 199 - col1
            color = getCellColor(ws.cell(row2, col2))
            fill = PatternFill(start_color=f"{color}", fill_type = "solid")
            ws.cell(row1, col1).fill = fill
    # quadrant 3
    for row3 in range(161, 321):
        row2 = 321 - row3
        for col3 in range(1, 100):
            col2 = 199 - col3
            color = getCellColor(ws.cell(row2, col2))
            fill = PatternFill(start_color=f"{color}", fill_type = "solid")
            ws.cell(row3, col3).fill = fill
    # quadrant 4
    for row4 in range(161, 321):
        row2 = 321 - row4
        for col4 in range(100, 199):
            col2 = col4
            color = getCellColor(ws.cell(row2, col2))
            fill = PatternFill(start_color=f"{color}", fill_type = "solid")
            ws.cell(row4, col4).fill = fill

def writeToCell(cell, color):
    row = ws[cell].row
    col = ws[cell].column
    rgb = codes[color]
    color = f"00{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"
    fill = PatternFill(start_color=f"{color}", fill_type = "solid")
    ws.cell(row, col).fill = fill
            
wb, ws = getActiveWorkbookAndSheet("MASTER")
corrections = {
    "EB9":'y',
    "EO5":'b',
    "FI5":'b',
    "GH7":'t',
    "FS7":'g',
    "EY7":'g',
    "GK65":'g',
    "FI12":'o',
    "EC28":'m',
    "FQ68":'m',
    "FR69":'m',
    "FQ70":'m',
    "FQ66":'m',
    "GE70":'m',
    "GE72":'m',
    "GE74":'m',
    "GE77":'m',
    "FZ43":'l',
    "GE67":'m',
    "GD68":'m',
    "FR72":'m',
    "DS53":'b',
    "FE73":'b',
    "DY80":'l',
    "FD84":'y',
    "EY79":'y',
    "ER88":'y',
    "EH74":'y',
    "EB73":'t',
    "DY79":'t',
    "FG78":'d',
    "EQ84":'d',
    "ER91":'d',
    "EU91":'p',
    "EV91":'p',
    "EU92":'p',
    "EV92":'p',
    "EU87":'p',
    "EY74":'b',
    "EZ74":'b',
    "FH72":'b',
    "FJ75":'w',
    "FI74":'b',
    "ER80":'d',
    "EP89":'g',
    "EQ90":'g',
    "ES90":'g',
    "ET89":'g',
    "EP90":'p',
    "FE74":'d',
    "EZ74":'d',
    "EY74":'d',
    "ET86":'p',
    "EU86":'p',
    "EU89":'o',
    "EU90":'o',
    "ET90":'o',
    "EN90":'o',
    "EO90":'o',
    "EN91":'o',
    "EO91":'o',
    "EV85":'p',
    "EV86":'p',
    "EV90":'p',
    "EN140":'m',
    "EJ98":'g',
    "EI97":'g',
    "EF66":'d',
    "EG66":'d',
    "ES68":'p',
    "ES69":'p',
    "ER69":'p',
    "EU71":'p',
    "EU70":'g',
    "FD66":'d',
    "FJ66":'d',
    "FE67":'d',
    "FE70":'d',
    "FF70":'d',
    "FG70":'w',
    "FH70":'d',
    "FG69":'d',
    "FE65":'b',
    "FF65":'b',
    "FH65":'b',
    "FI65":'b',
    "DE151":'t',
    "DE152":'t',
    "DE153":'t',
    "DF151":'t',
    "DF152":'t',    
    "DF153":'t',
    "DE154":'t',
    "CZ158":'b',
    "CZ159":'b',
    }
for cell, color in corrections.items():
    writeToCell(cell, color)
duplicate({'start':"FL46", 'end':"GP85", 'target':"FL86"})
duplicate({'start':"FL46", 'end':"GP85", 'target':"FL126"})
duplicate({'start':"FL45", 'end':"GP83", 'target':"FL162"})
target = newCell("EA1", diff("EA1", "FO1"))
duplicate({'start':"EA1",  'end':"FO32", 'target':target})
target = newCell(target, diff("EA1", "FO1"))
duplicate({'start':"EA1",  'end':"FO32", 'target':target})
duplicateQuadrants()

FILENAME="MASTER"
wb.save(f'data/{FILENAME}.xlsx')
print("duplication complete")
